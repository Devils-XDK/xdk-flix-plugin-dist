// Custom Flutter bootstrap for XDKNet Web.
//
// Service workers. The default bootstrap registers flutter_service_worker.js,
// which caches the app shell in Cache Storage and keeps serving it after the
// plugin is updated. Because a browser's "clear cache" does not unregister a
// service worker, an updated XDKNet plugin could keep booting the previous
// build indefinitely. Both plugins serve every file with headers that make the
// browser revalidate it (index.html is never stored at all), so the app needs
// no service worker for correctness. Loading without serviceWorkerSettings
// keeps one from being registered, and cleanupLegacyFlutterWorker() removes one
// left behind by an earlier build. That cleanup runs once per browser, and it
// only touches Flutter's own worker and caches: the page shares its origin
// with the Jellyfin or Emby web client, whose worker and caches are not ours.
//
// No internet. The server is often on a LAN with no route out, so nothing the
// app needs in order to start may come from a CDN. The web build passes
// --no-web-resources-cdn, which ships CanvasKit/Skwasm in canvaskit/ and makes
// the loader use that copy; hls.js is vendored in vendor/hls/ (see index.html);
// and Roboto, the font the engine downloads before the first frame, is vendored
// in vendor/flutter-fonts/ under the path the engine asks for. The engine takes
// every font it downloads from one base URL, fontFallbackBaseUrl, so that base
// points at Google Fonts when Google Fonts answers and at the vendored copy
// when it does not. Only Roboto is vendored: the fallback fonts for emoji, CJK
// and other scripts are hundreds of files, so without internet those
// characters still show as boxes.
//
// One thread. On a cross-origin isolated page (the Jellyfin plugin's
// Cross-origin isolation option makes it one) Flutter 3.44 runs Skwasm
// multi-threaded: the page's thread lays text out while a separate worker
// draws it. Both reach into Skia's glyph cache and FreeType's font faces, and
// the locks meant to keep them apart do nothing in this build, so sooner or
// later the two collide, the renderer stops with "memory access out of
// bounds" and the page freezes. forceSingleThreadedSkwasm keeps drawing on
// the page's thread, which is how Skwasm already runs on every page that is
// not isolated. The upstream reports are flutter/flutter#190039 (the glyph
// cache, fixed on master by #190048) and #193439 (the FreeType face lock,
// still racy on 3.49 pre-releases). Revisit this once a Flutter release has
// fixes for both. scripts/check-web-bundle.sh fails a bundle without it.
//
// Failure. The loader overlay in index.html is removed by the first frame. If
// loading fails, or the first frame is slow to come, the overlay says so and
// offers Retry instead of spinning forever. A renderer that fails after the
// first frame (a WebAssembly trap in Skwasm or CanvasKit) leaves a page that
// no longer draws or answers, so the overlay comes back once to say so, with
// the same Retry. Nothing reloads by itself, and no other error brings the
// overlay back.

(()=>{var _={blink:!0,gecko:!1,webkit:!1,unknown:!1},K=()=>navigator.vendor==="Google Inc."||navigator.userAgent.includes("Edg/")?"blink":navigator.vendor==="Apple Computer, Inc."?"webkit":navigator.vendor===""&&navigator.userAgent.includes("Firefox")?"gecko":"unknown",C=K(),R=()=>typeof ImageDecoder>"u"?!1:C==="blink",B=()=>typeof Intl.v8BreakIterator<"u"&&typeof Intl.Segmenter<"u",z=()=>{let i=[0,97,115,109,1,0,0,0,1,5,1,95,1,120,0];return WebAssembly.validate(new Uint8Array(i))},M=()=>{let i=document.createElement("canvas");return i.width=1,i.height=1,i.getContext("webgl2")!=null?2:i.getContext("webgl")!=null?1:-1},D=()=>window.chrome&&chrome.runtime&&chrome.runtime.id,w={browserEngine:C,hasImageCodecs:R(),hasChromiumBreakIterators:B(),supportsWasmGC:z(),crossOriginIsolated:window.crossOriginIsolated,webGLVersion:M(),isChromeExtension:D()};function c(...i){return new URL(I(...i),document.baseURI).toString()}function I(...i){return i.filter(e=>!!e).map((e,n)=>n===0?S(e):F(S(e))).filter(e=>e.length).join("/")}function F(i){let e=0;for(;e<i.length&&i.charAt(e)==="/";)e++;return i.substring(e)}function S(i){let e=i.length;for(;e>0&&i.charAt(e-1)==="/";)e--;return i.substring(0,e)}function E(i,e){return i.canvasKitBaseUrl?i.canvasKitBaseUrl:e.engineRevision&&!e.useLocalCanvasKit?I("https://www.gstatic.com/flutter-canvaskit",e.engineRevision):"canvaskit"}var v=class{constructor(){this._scriptLoaded=!1}setTrustedTypesPolicy(e){this._ttPolicy=e}async loadEntrypoint(e){let{entrypointUrl:n=c("main.dart.js"),onEntrypointLoaded:t,nonce:r}=e||{};return this._loadJSEntrypoint(n,t,r)}async load(e,n,t,r,a){a??=l=>{l.initializeEngine(t).then(u=>u.runApp())};let{entrypointBaseUrl:s}=t,{entryPointBaseUrl:o}=t;if(!s&&o&&(console.warn("[deprecated] `entryPointBaseUrl` is deprecated and will be removed in a future release. Use `entrypointBaseUrl` instead."),s=o),e.compileTarget==="dart2wasm")return this._loadWasmEntrypoint(e,n,s,a);{let l=e.mainJsPath??"main.dart.js",u=c(s,l);return this._loadJSEntrypoint(u,a,r)}}didCreateEngineInitializer(e){typeof this._didCreateEngineInitializerResolve=="function"&&(this._didCreateEngineInitializerResolve(e),this._didCreateEngineInitializerResolve=null,delete _flutter.loader.didCreateEngineInitializer),typeof this._onEntrypointLoaded=="function"&&this._onEntrypointLoaded(e)}_loadJSEntrypoint(e,n,t){let r=typeof n=="function";if(!this._scriptLoaded){this._scriptLoaded=!0;let a=this._createScriptTag(e,t);if(r)console.debug("Injecting <script> tag. Using callback."),this._onEntrypointLoaded=n,document.head.append(a);else return new Promise((s,o)=>{console.debug("Injecting <script> tag. Using Promises. Use the callback approach instead!"),this._didCreateEngineInitializerResolve=s,a.addEventListener("error",o),document.head.append(a)})}}async _loadWasmEntrypoint(e,n,t,r){if(!this._scriptLoaded){this._scriptLoaded=!0,this._onEntrypointLoaded=r;let{mainWasmPath:a,jsSupportRuntimePath:s}=e,o=c(t,a),l=c(t,s);this._ttPolicy!=null&&(l=this._ttPolicy.createScriptURL(l));let d=(await import(l)).compileStreaming(fetch(o)),p;e.renderer==="skwasm"?p=(async()=>{let h=await n.skwasm;return window._flutter_skwasmInstance=h,{skwasm:h.wasmExports,skwasmWrapper:h,ffi:{memory:h.wasmMemory}}})():p=Promise.resolve({}),await(await(await d).instantiate(await p,{loadDynamicModule:async(h,j)=>{let A=fetch(c(t,h)),L=c(t,j);this._ttPolicy!=null&&(L=this._ttPolicy.createScriptURL(L));let x=import(L);return[await A,await x]}})).invokeMain()}}_createScriptTag(e,n){let t=document.createElement("script");t.type="application/javascript",n&&(t.nonce=n);let r=e;return this._ttPolicy!=null&&(r=this._ttPolicy.createScriptURL(e)),t.src=r,t}};async function T(i,e,n){if(e<0)return i;let t,r=new Promise((a,s)=>{t=setTimeout(()=>{s(new Error(`${n} took more than ${e}ms to resolve. Moving on.`,{cause:T}))},e)});return Promise.race([i,r]).finally(()=>{clearTimeout(t)})}var g=class{setTrustedTypesPolicy(e){this._ttPolicy=e}loadServiceWorker(e){if(!e||!("serviceWorker"in navigator))return Promise.resolve();let n=()=>{console.warn(`Loading the service worker using Flutter bootstrap is deprecated and will stop working in a future release.
For more details, see: https://github.com/flutter/flutter/issues/156910`)},t=()=>{let{serviceWorkerVersion:r,serviceWorkerUrl:a=c(`flutter_service_worker.js?v=${r}`),timeoutMillis:s=4e3}=e,o=a;this._ttPolicy!=null&&(o=this._ttPolicy.createScriptURL(o));let l=navigator.serviceWorker.register(o).then(u=>this._getNewServiceWorker(u,r)).then(this._waitForServiceWorkerActivation);return T(l,s,"prepareServiceWorker")};return e.serviceWorkerUrl!=null?(n(),t()):navigator.serviceWorker.getRegistration().then(r=>r?t():Promise.resolve())}async _getNewServiceWorker(e,n){if(!e.active&&(e.installing||e.waiting))return console.debug("Installing/Activating first service worker."),e.installing||e.waiting;if(e.active.scriptURL.endsWith(n))return console.debug("Loading from existing service worker."),e.active;{let t=await e.update();return console.debug("Updating service worker."),t.installing||t.waiting||t.active}}async _waitForServiceWorkerActivation(e){if(!e||e.state==="activated")if(e){console.debug("Service worker already active.");return}else throw new Error("Cannot activate a null service worker!");return new Promise((n,t)=>{e.addEventListener("statechange",()=>{e.state==="activated"&&(console.debug("Activated new service worker."),n())})})}};var y=class{constructor(e,n="flutter-js"){let t=e||[/\.js$/,/\.mjs$/];window.trustedTypes&&(this.policy=trustedTypes.createPolicy(n,{createScriptURL:function(r){if(r.startsWith("blob:"))return r;let a=new URL(r,window.location),s=a.pathname.split("/").pop();if(t.some(l=>l.test(s)))return a.toString();console.error("URL rejected by TrustedTypes policy",n,":",r,"(download prevented)")}}))}};var k=i=>{let e=WebAssembly.compileStreaming(fetch(i));return(n,t)=>((async()=>{let r=await e,a=await WebAssembly.instantiate(r,n);t(a,r)})(),{})};var U=(i,e,n,t)=>(window.flutterCanvasKitLoaded=(async()=>{if(window.flutterCanvasKit)return window.flutterCanvasKit;let r=n.hasChromiumBreakIterators&&n.hasImageCodecs;if(!r&&e.canvasKitVariant=="chromium")throw"Chromium CanvasKit variant specifically requested, but unsupported in this browser";let a=r&&e.canvasKitVariant!=="full",s=t;e.canvasKitVariant=="experimentalWebParagraph"?s=c(s,"experimental_webparagraph"):a&&(s=c(s,"chromium"));let o=c(s,"canvaskit.js");i.flutterTT.policy&&(o=i.flutterTT.policy.createScriptURL(o));let l=k(c(s,"canvaskit.wasm")),u=await import(o);return window.flutterCanvasKit=await u.default({instantiateWasm:l}),window.flutterCanvasKit})(),window.flutterCanvasKitLoaded);var W=async(i,e,n,t)=>{let a=!n.hasImageCodecs||!n.hasChromiumBreakIterators?"skwasm_heavy":e.enableWimp?"wimp":"skwasm",s=c(t,`${a}.js`),o=s;i.flutterTT.policy&&(o=i.flutterTT.policy.createScriptURL(o));let l=k(c(t,`${a}.wasm`));return await(await import(o)).default({skwasmSingleThreaded:e.enableWimp||!n.crossOriginIsolated||n.isChromeExtension||e.forceSingleThreadedSkwasm,instantiateWasm:l,locateFile:(d,p)=>d.endsWith(".ww.js")?URL.createObjectURL(new Blob([`
"use strict";

let eventListener;
eventListener = (message) => {
    const pendingMessages = [];
    const data = message.data;
    data["instantiateWasm"] = (info,receiveInstance) => {
        const instance = new WebAssembly.Instance(data["wasm"], info);
        return receiveInstance(instance, data["wasm"])
    };
    import(data.js).then(async (skwasm) => {
        await skwasm.default(data);

        removeEventListener("message", eventListener);
        for (const message of pendingMessages) {
            dispatchEvent(message);
        }
    });
    removeEventListener("message", eventListener);
    eventListener = (message) => {

        pendingMessages.push(message);
    };

    addEventListener("message", eventListener);
};
addEventListener("message", eventListener);
`],{type:"application/javascript"})):c(t,d),mainScriptUrlOrBlob:s})};var P=w.supportsWasmGC,G=P&&w.webGLVersion>0,b=class{async loadEntrypoint(e){let{serviceWorker:n,...t}=e||{},r=new y,a=new g;a.setTrustedTypesPolicy(r.policy),await a.loadServiceWorker(n).catch(o=>{console.warn("Exception while loading service worker:",o)});let s=new v;return s.setTrustedTypesPolicy(r.policy),this.didCreateEngineInitializer=s.didCreateEngineInitializer.bind(s),s.loadEntrypoint(t)}async load({serviceWorkerSettings:e,onEntrypointLoaded:n,nonce:t,config:r}={}){r??={};let a=_flutter.buildConfig;if(!a)throw"FlutterLoader.load requires _flutter.buildConfig to be set";let s=r.wasmAllowList?.[w.browserEngine]??_[w.browserEngine],o=m=>{switch(m){case"skwasm":return G&&s;default:return!0}},l=m=>m.compileTarget==="dart2wasm"&&!P||r.renderer&&r.renderer!=m.renderer?!1:o(m.renderer),u=a.builds.find(l);if(!u)throw"FlutterLoader could not find a build compatible with configuration and environment.";let d={};d.flutterTT=new y,e&&(d.serviceWorkerLoader=new g,d.serviceWorkerLoader.setTrustedTypesPolicy(d.flutterTT.policy),await d.serviceWorkerLoader.loadServiceWorker(e).catch(m=>{console.warn("Exception while loading service worker:",m)}));let p=E(r,a);u.renderer==="canvaskit"?d.canvasKit=U(d,r,w,p):u.renderer==="skwasm"&&(d.skwasm=W(d,r,w,p));let f=new v;return f.setTrustedTypesPolicy(d.flutterTT.policy),this.didCreateEngineInitializer=f.didCreateEngineInitializer.bind(f),f.load(u,d,r,t,n)}};window._flutter||(window._flutter={});window._flutter.loader||(window._flutter.loader=new b);})();
//# sourceMappingURL=flutter.js.map

if (!window._flutter) {
  window._flutter = {};
}
_flutter.buildConfig = {"engineRevision":"0cd610717bde95fd88343c64f81c11ba4e5c0010","builds":[{"compileTarget":"dart2wasm","renderer":"skwasm","mainWasmPath":"main.dart.wasm","jsSupportRuntimePath":"main.dart.mjs"},{"compileTarget":"dart2js","renderer":"canvaskit","mainJsPath":"main.dart.js"}],"useLocalCanvasKit":true};


(function () {
  'use strict';

  var CLEANUP_DONE_KEY = 'xdknet.flutterWorkerCleanup.v1';
  var FLUTTER_CACHE_NAMES = [
    'flutter-app-cache',
    'flutter-temp-cache',
    'flutter-app-manifest',
  ];

  var GOOGLE_FONTS_BASE = 'https://fonts.gstatic.com/s/';
  // The engine's _robotoUrl, relative to fontFallbackBaseUrl. It belongs to the
  // Flutter version the app is built with; the web build workflow checks that
  // the vendored file still matches.
  var ROBOTO_PATH = 'roboto/v32/KFOmCnqEu92Fr1Me4GZLCzYlKw.woff2';
  var FONT_PROBE_TIMEOUT_MS = 5000;

  // Long enough for the ~20 MB bundle over a slow link. Past it the overlay
  // only offers a Retry; loading carries on underneath.
  var SLOW_START_MS = 30000;

  var appBase = new URL('.', document.baseURI).href;
  var vendoredFontBase = new URL('vendor/flutter-fonts/', appBase).href;
  var googleFontsReachable = false;
  var firstFrameShown = false;
  var startupFailed = false;
  var rendererFailed = false;

  // index.html takes the overlay out of the page after the first frame, so a
  // reference is kept for a renderer that fails later.
  var loaderOverlay = document.getElementById('xdknet-loader');

  function readFlag(key) {
    try {
      return window.localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function writeFlag(key, value) {
    try {
      window.localStorage.setItem(key, value);
    } catch (e) {}
  }

  function isFlutterWorkerScript(url) {
    return typeof url === 'string' && /\/flutter_service_worker\.js(\?|#|$)/.test(url);
  }

  // A worker is XDKNet's when its scope is the app's own directory (or below
  // it), or when its script is Flutter's worker. The stock web client's
  // worker lives elsewhere on the origin and fails both tests.
  function isXdkNetRegistration(registration, base) {
    if (!registration) return false;
    var scope = typeof registration.scope === 'string' ? registration.scope.toLowerCase() : '';
    if (scope && scope.indexOf(base) === 0) return true;
    var workers = [registration.active, registration.waiting, registration.installing];
    for (var i = 0; i < workers.length; i++) {
      if (workers[i] && isFlutterWorkerScript(workers[i].scriptURL)) return true;
    }
    return false;
  }

  function cleanupLegacyFlutterWorker() {
    if (readFlag(CLEANUP_DONE_KEY) === '1') {
      return Promise.resolve();
    }

    var base = appBase.toLowerCase();
    var jobs = [];

    try {
      if ('serviceWorker' in navigator && navigator.serviceWorker.getRegistrations) {
        jobs.push(
          navigator.serviceWorker
            .getRegistrations()
            .then(function (registrations) {
              return Promise.all(
                registrations
                  .filter(function (registration) {
                    return isXdkNetRegistration(registration, base);
                  })
                  .map(function (registration) {
                    return registration.unregister().catch(function () {});
                  })
              );
            })
            .catch(function () {})
        );
      }
    } catch (e) {}

    try {
      if (window.caches && window.caches.delete) {
        FLUTTER_CACHE_NAMES.forEach(function (name) {
          jobs.push(window.caches.delete(name).catch(function () {}));
        });
      }
    } catch (e) {}

    return Promise.all(jobs).then(
      function () {
        writeFlag(CLEANUP_DONE_KEY, '1');
      },
      function () {}
    );
  }

  // Also warms the HTTP cache: when Google Fonts answers, the engine's own
  // request for Roboto is served from this response.
  function probeGoogleFonts() {
    if (typeof fetch !== 'function') return;
    var controller = typeof AbortController === 'function' ? new AbortController() : null;
    var timer = setTimeout(function () {
      if (controller) controller.abort();
    }, FONT_PROBE_TIMEOUT_MS);
    var init = { mode: 'cors', credentials: 'omit' };
    if (controller) init.signal = controller.signal;

    fetch(GOOGLE_FONTS_BASE + ROBOTO_PATH, init)
      .then(function (response) {
        if (!response || !response.ok) return;
        return response.arrayBuffer().then(function () {
          googleFontsReachable = true;
        });
      })
      .catch(function () {})
      .then(function () {
        clearTimeout(timer);
      });
  }

  // Both the loader, which starts Skwasm, and the engine get this. See "One
  // thread." above; the bundle check looks for this line as it is written.
  var engineConfig = {
    forceSingleThreadedSkwasm: true,
  };

  // The engine reads fontFallbackBaseUrl when it goes to download a font (for
  // Roboto, once the bundle has loaded; for fallback fonts, each time), not
  // when it is handed the configuration, so a getter lets the probe's answer
  // take effect whenever it arrives. Until then the vendored copy is used,
  // which keeps a network that silently drops requests from holding up the
  // start.
  Object.defineProperty(engineConfig, 'fontFallbackBaseUrl', {
    enumerable: true,
    get: function () {
      return googleFontsReachable ? GOOGLE_FONTS_BASE : vendoredFontBase;
    },
  });

  function loaderElement() {
    return document.getElementById('xdknet-loader');
  }

  function showStatus(kind, message, detail) {
    var loader = loaderElement();
    if (!loader) return;
    var status = loader.querySelector('.xdknet-loader__status');
    if (!status) return;

    loader.classList.remove('xdknet-loader--slow');
    loader.classList.add('xdknet-loader--' + kind);
    loader.removeAttribute('aria-hidden');

    var messageEl = status.querySelector('.xdknet-loader__message');
    var detailEl = status.querySelector('.xdknet-loader__detail');
    var retry = status.querySelector('.xdknet-loader__retry');
    if (messageEl) messageEl.textContent = message;
    if (detailEl) detailEl.textContent = detail;
    if (retry && !retry.getAttribute('data-bound')) {
      retry.setAttribute('data-bound', '1');
      retry.addEventListener('click', function () {
        window.location.reload();
      });
    }
    status.hidden = false;
    if (retry && kind === 'failed') {
      try {
        retry.focus();
      } catch (e) {}
    }
  }

  function describeError(error) {
    var text = '';
    try {
      text = error && error.message ? String(error.message) : String(error);
    } catch (e) {}
    text = text.replace(/\s+/g, ' ').trim();
    return text.length > 300 ? text.substring(0, 300) + '...' : text;
  }

  function showStartupFailure(error) {
    if (firstFrameShown || startupFailed) return;
    startupFailed = true;
    try {
      console.error('XDKNet could not start:', error);
    } catch (e) {}
    var reason = describeError(error);
    showStatus(
      'failed',
      'XDKNet could not start.',
      'Check that this device can reach the server, then try again.' +
        (reason ? ' (' + reason + ')' : '')
    );
  }

  function watchStartup() {
    window.addEventListener('flutter-first-frame', function () {
      firstFrameShown = true;
    });

    // With a JS build the loader injects main.dart.js as a plain <script> and
    // reports nothing when it fails to load.
    window.addEventListener(
      'error',
      function (event) {
        var target = event && event.target;
        if (target && target.tagName === 'SCRIPT' && /main\.dart\.m?js(\?|$)/.test(target.src || '')) {
          showStartupFailure(new Error('Could not load ' + target.src));
        }
      },
      true
    );

    setTimeout(function () {
      if (firstFrameShown || startupFailed) return;
      showStatus(
        'slow',
        'XDKNet is taking longer than usual to start.',
        'If this does not change, check that this device can reach the server, then try again.'
      );
    }, SLOW_START_MS);
  }

  // An uncaught WebAssembly trap with the renderer's own code on the stack.
  // After one, the renderer's memory cannot be trusted, and in practice every
  // later frame fails as well.
  function isRendererFault(error) {
    try {
      if (typeof WebAssembly !== 'object' || typeof WebAssembly.RuntimeError !== 'function') {
        return false;
      }
      return error instanceof WebAssembly.RuntimeError && /skwasm|canvaskit/i.test(String(error.stack || ''));
    } catch (e) {
      return false;
    }
  }

  // Before the first frame the startup notices above already cover a start
  // that goes wrong.
  function showRendererFailure(error) {
    if (!firstFrameShown || rendererFailed || !loaderOverlay) return;
    rendererFailed = true;
    if (!loaderOverlay.parentNode && document.body) {
      document.body.appendChild(loaderOverlay);
    }
    loaderOverlay.classList.remove('ready');
    var reason = describeError(error);
    showStatus(
      'failed',
      'XDKNet stopped working.',
      'Something went wrong while drawing the page. Reload it to carry on.' +
        (reason ? ' (' + reason + ')' : '')
    );
  }

  // Only a renderer fault: every other error is left to the app.
  function watchRenderer() {
    window.addEventListener('error', function (event) {
      if (event && isRendererFault(event.error)) showRendererFailure(event.error);
    });
  }

  function loadApp() {
    try {
      var loading = _flutter.loader.load({
        config: engineConfig,
        onEntrypointLoaded: function (engineInitializer) {
          return engineInitializer
            .initializeEngine(engineConfig)
            .then(function (appRunner) {
              return appRunner.runApp();
            })
            .catch(showStartupFailure);
        },
      });
      if (loading && typeof loading.then === 'function') {
        loading.then(null, showStartupFailure);
      }
    } catch (e) {
      showStartupFailure(e);
    }
  }

  watchStartup();
  watchRenderer();
  probeGoogleFonts();
  // Never let cleanup failures block startup.
  cleanupLegacyFlutterWorker().then(loadApp, loadApp);
})();
