// Compiles a dart2wasm-generated main module from `source` which can then
// instantiatable via the `instantiate` method.
//
// `source` needs to be a `Response` object (or promise thereof) e.g. created
// via the `fetch()` JS API.
export async function compileStreaming(source) {
  const builtins = {builtins: ['js-string']};
  return new CompiledApp(
      await WebAssembly.compileStreaming(source, builtins), builtins);
}

// Compiles a dart2wasm-generated wasm modules from `bytes` which is then
// instantiatable via the `instantiate` method.
export async function compile(bytes) {
  const builtins = {builtins: ['js-string']};
  return new CompiledApp(await WebAssembly.compile(bytes, builtins), builtins);
}

// DEPRECATED: Please use `compile` or `compileStreaming` to get a compiled app,
// use `instantiate` method to get an instantiated app and then call
// `invokeMain` to invoke the main function.
export async function instantiate(modulePromise, importObjectPromise) {
  var moduleOrCompiledApp = await modulePromise;
  if (!(moduleOrCompiledApp instanceof CompiledApp)) {
    moduleOrCompiledApp = new CompiledApp(moduleOrCompiledApp);
  }
  const instantiatedApp = await moduleOrCompiledApp.instantiate(await importObjectPromise);
  return instantiatedApp.instantiatedModule;
}

// DEPRECATED: Please use `compile` or `compileStreaming` to get a compiled app,
// use `instantiate` method to get an instantiated app and then call
// `invokeMain` to invoke the main function.
export const invoke = (moduleInstance, ...args) => {
  moduleInstance.exports.$invokeMain(args);
}

class CompiledApp {
  constructor(module, builtins) {
    this.module = module;
    this.builtins = builtins;
  }

  // The second argument is an options object containing:
  // `loadDeferredModules` is a JS function that takes an array of module names
  //   matching wasm files produced by the dart2wasm compiler. It also takes a
  //   callback that should be invoked for each loaded module with 2 arugments:
  //   (1) the module name, (2) the loaded module in a format supported by
  //   `WebAssembly.compile` or `WebAssembly.compileStreaming`. The callback
  //   returns a Promise that resolves when the module is instantiated.
  //   loadDeferredModules should return a Promise that resolves when all the
  //   modules have been loaded and the callback promises have resolved.
  // `loadDeferredId` is a JS function that takes load ID produced by the
  //   compiler when the `load-ids` option is passed. Each load ID maps to one
  //   or more wasm files as specified in the emitted JSON file. It also takes a
  //   callback that should be invoked for each loaded module with 2 arugments:
  //   (1) the module name, (2) the loaded module in a format supported by
  //   `WebAssembly.compile` or `WebAssembly.compileStreaming`. The callback
  //   returns a Promise that resolves when the module is instantiated.
  //   loadDeferredModules should return a Promise that resolves when all the
  //   modules have been loaded and the callback promises have resolved.
  // `loadDynamicModule` is a JS function that takes two string names matching,
  //   in order, a wasm file produced by the dart2wasm compiler during dynamic
  //   module compilation and a corresponding js file produced by the same
  //   compilation. It also takes a callback that should be invoked with the
  //   loaded module in a format supported by `WebAssembly.compile` or
  //   `WebAssembly.compileStreaming` and the result of using the JS 'import'
  //   API on the js file path. It should return a Promise that resolves when
  //   all the modules have been loaded and the callback promises have resolved.
  async instantiate(additionalImports,
      {loadDeferredModules, loadDynamicModule, loadDeferredId} = {}) {
    let dartInstance;

    // Prints to the console
    function printToConsole(value) {
      if (typeof dartPrint == "function") {
        dartPrint(value);
        return;
      }
      if (typeof console == "object" && typeof console.log != "undefined") {
        console.log(value);
        return;
      }
      if (typeof print == "function") {
        print(value);
        return;
      }

      throw "Unable to print message: " + value;
    }

    // A special symbol attached to functions that wrap Dart functions.
    const jsWrappedDartFunctionSymbol = Symbol("JSWrappedDartFunction");

    function finalizeWrapper(dartFunction, wrapped) {
      wrapped.dartFunction = dartFunction;
      wrapped[jsWrappedDartFunctionSymbol] = true;
      return wrapped;
    }

    // Imports
    const dart2wasm = {
            _1: (decoder, codeUnits) => decoder.decode(codeUnits),
      _2: () => new TextDecoder("utf-8", {fatal: true}),
      _3: () => new TextDecoder("utf-8", {fatal: false}),
      _4: (s) => +s,
      _5: x0 => new Uint8Array(x0),
      _6: (x0,x1,x2) => x0.set(x1,x2),
      _7: (x0,x1) => x0.transferFromImageBitmap(x1),
      _8: x0 => x0.arrayBuffer(),
      _9: (x0,x1,x2) => x0.slice(x1,x2),
      _10: (x0,x1) => x0.decode(x1),
      _11: (x0,x1) => x0.segment(x1),
      _12: () => new TextDecoder(),
      _13: (x0,x1) => x0.get(x1),
      _14: x0 => x0.buffer,
      _15: x0 => x0.wasmMemory,
      _16: () => globalThis.window._flutter_skwasmInstance,
      _17: x0 => x0.rasterStartMilliseconds,
      _18: x0 => x0.rasterEndMilliseconds,
      _19: x0 => x0.imageBitmaps,
      _135: (x0,x1) => x0.appendChild(x1),
      _166: (x0,x1,x2) => x0.addEventListener(x1,x2),
      _167: (x0,x1,x2) => x0.removeEventListener(x1,x2),
      _168: (x0,x1) => new OffscreenCanvas(x0,x1),
      _169: x0 => x0.remove(),
      _170: (x0,x1) => x0.append(x1),
      _172: x0 => x0.unlock(),
      _173: x0 => x0.getReader(),
      _174: (x0,x1) => x0.item(x1),
      _175: x0 => x0.next(),
      _176: x0 => x0.now(),
      _177: (x0,x1) => x0.revokeObjectURL(x1),
      _178: x0 => x0.close(),
      _179: (x0,x1,x2,x3,x4) => ({type: x0,data: x1,premultiplyAlpha: x2,colorSpaceConversion: x3,preferAnimation: x4}),
      _180: x0 => new window.ImageDecoder(x0),
      _181: (x0,x1) => ({frameIndex: x0,completeFramesOnly: x1}),
      _182: (x0,x1) => x0.decode(x1),
      _183: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._183(f,arguments.length,x0) }),
      _184: (x0,x1,x2,x3) => x0.addEventListener(x1,x2,x3),
      _186: (x0,x1) => x0.getModifierState(x1),
      _187: x0 => x0.preventDefault(),
      _188: x0 => x0.stopPropagation(),
      _189: (x0,x1) => x0.removeProperty(x1),
      _190: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._190(f,arguments.length,x0) }),
      _191: x0 => new window.FinalizationRegistry(x0),
      _192: (x0,x1,x2,x3) => x0.register(x1,x2,x3),
      _194: (x0,x1) => x0.unregister(x1),
      _195: (x0,x1) => x0.prepend(x1),
      _196: x0 => new Intl.Locale(x0),
      _197: (x0,x1) => x0.observe(x1),
      _198: x0 => x0.disconnect(),
      _199: (x0,x1) => x0.getAttribute(x1),
      _200: (x0,x1) => x0.contains(x1),
      _201: (x0,x1) => x0.querySelector(x1),
      _202: (x0,x1) => x0.matchMedia(x1),
      _203: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._203(f,arguments.length,x0) }),
      _204: (x0,x1,x2) => x0.call(x1,x2),
      _205: x0 => x0.blur(),
      _206: x0 => x0.hasFocus(),
      _207: (x0,x1) => x0.removeAttribute(x1),
      _208: (x0,x1,x2) => x0.insertBefore(x1,x2),
      _209: (x0,x1) => x0.hasAttribute(x1),
      _210: (x0,x1) => x0.getModifierState(x1),
      _211: (x0,x1) => x0.createTextNode(x1),
      _212: x0 => x0.getBoundingClientRect(),
      _213: (x0,x1) => x0.replaceWith(x1),
      _214: (x0,x1) => x0.contains(x1),
      _215: (x0,x1) => x0.closest(x1),
      _216: () => new Array(),
      _653: x0 => new Uint8Array(x0),
      _656: () => globalThis.window.flutterConfiguration,
      _658: x0 => x0.assetBase,
      _663: x0 => x0.canvasKitMaximumSurfaces,
      _664: x0 => x0.debugShowSemanticsNodes,
      _665: x0 => x0.hostElement,
      _666: x0 => x0.multiViewEnabled,
      _667: x0 => x0.nonce,
      _669: x0 => x0.fontFallbackBaseUrl,
      _679: x0 => x0.console,
      _680: x0 => x0.devicePixelRatio,
      _681: x0 => x0.document,
      _682: x0 => x0.history,
      _683: x0 => x0.innerHeight,
      _684: x0 => x0.innerWidth,
      _685: x0 => x0.location,
      _686: x0 => x0.navigator,
      _687: x0 => x0.visualViewport,
      _688: x0 => x0.performance,
      _689: x0 => x0.parent,
      _691: x0 => x0.URL,
      _693: (x0,x1) => x0.getComputedStyle(x1),
      _694: x0 => x0.screen,
      _695: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._695(f,arguments.length,x0) }),
      _696: (x0,x1) => x0.requestAnimationFrame(x1),
      _700: (x0,x1) => x0.warn(x1),
      _702: (x0,x1) => x0.debug(x1),
      _703: x0 => globalThis.parseFloat(x0),
      _704: () => globalThis.window,
      _705: () => globalThis.Intl,
      _706: () => globalThis.Symbol,
      _707: (x0,x1,x2,x3,x4) => globalThis.createImageBitmap(x0,x1,x2,x3,x4),
      _709: x0 => x0.clipboard,
      _710: x0 => x0.maxTouchPoints,
      _711: x0 => x0.vendor,
      _712: x0 => x0.language,
      _713: x0 => x0.platform,
      _714: x0 => x0.userAgent,
      _715: (x0,x1) => x0.vibrate(x1),
      _716: x0 => x0.languages,
      _717: x0 => x0.documentElement,
      _718: (x0,x1) => x0.querySelector(x1),
      _719: (x0,x1) => x0.querySelectorAll(x1),
      _721: (x0,x1) => x0.createElement(x1),
      _724: (x0,x1) => x0.createEvent(x1),
      _725: x0 => x0.activeElement,
      _728: x0 => x0.head,
      _729: x0 => x0.body,
      _731: (x0,x1) => { x0.title = x1 },
      _734: x0 => x0.visibilityState,
      _735: () => globalThis.document,
      _736: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._736(f,arguments.length,x0) }),
      _737: (x0,x1) => x0.dispatchEvent(x1),
      _745: x0 => x0.target,
      _747: x0 => x0.timeStamp,
      _748: x0 => x0.type,
      _750: (x0,x1,x2,x3) => x0.initEvent(x1,x2,x3),
      _756: x0 => x0.baseURI,
      _757: x0 => x0.firstChild,
      _761: x0 => x0.parentElement,
      _763: (x0,x1) => { x0.textContent = x1 },
      _764: x0 => x0.parentNode,
      _765: x0 => x0.nextSibling,
      _766: (x0,x1) => x0.removeChild(x1),
      _767: x0 => x0.isConnected,
      _775: x0 => x0.clientHeight,
      _776: x0 => x0.clientWidth,
      _777: x0 => x0.offsetHeight,
      _778: x0 => x0.offsetWidth,
      _779: x0 => x0.id,
      _780: (x0,x1) => { x0.id = x1 },
      _783: (x0,x1) => { x0.spellcheck = x1 },
      _784: x0 => x0.tagName,
      _785: x0 => x0.style,
      _787: (x0,x1) => x0.querySelectorAll(x1),
      _788: (x0,x1,x2) => x0.setAttribute(x1,x2),
      _789: x0 => x0.tabIndex,
      _790: (x0,x1) => { x0.tabIndex = x1 },
      _791: (x0,x1) => x0.focus(x1),
      _792: x0 => x0.scrollTop,
      _793: (x0,x1) => { x0.scrollTop = x1 },
      _794: (x0,x1) => { x0.scrollLeft = x1 },
      _795: x0 => x0.scrollLeft,
      _796: x0 => x0.classList,
      _797: (x0,x1) => x0.scrollIntoView(x1),
      _800: (x0,x1) => { x0.className = x1 },
      _802: (x0,x1) => x0.getElementsByClassName(x1),
      _803: x0 => x0.click(),
      _804: (x0,x1) => x0.attachShadow(x1),
      _807: x0 => x0.computedStyleMap(),
      _808: (x0,x1) => x0.get(x1),
      _814: (x0,x1) => x0.getPropertyValue(x1),
      _815: (x0,x1,x2,x3) => x0.setProperty(x1,x2,x3),
      _816: x0 => x0.offsetLeft,
      _817: x0 => x0.offsetTop,
      _818: x0 => x0.offsetParent,
      _820: (x0,x1) => { x0.name = x1 },
      _821: x0 => x0.content,
      _822: (x0,x1) => { x0.content = x1 },
      _826: (x0,x1) => { x0.src = x1 },
      _827: x0 => x0.naturalWidth,
      _828: x0 => x0.naturalHeight,
      _832: (x0,x1) => { x0.crossOrigin = x1 },
      _834: (x0,x1) => { x0.decoding = x1 },
      _835: x0 => x0.decode(),
      _840: (x0,x1) => { x0.nonce = x1 },
      _845: (x0,x1) => { x0.width = x1 },
      _847: (x0,x1) => { x0.height = x1 },
      _850: (x0,x1) => x0.getContext(x1),
      _918: x0 => x0.width,
      _919: x0 => x0.height,
      _921: (x0,x1) => x0.fetch(x1),
      _922: x0 => x0.status,
      _923: x0 => x0.headers,
      _924: x0 => x0.body,
      _925: x0 => x0.arrayBuffer(),
      _927: x0 => x0.text(),
      _928: x0 => x0.read(),
      _929: x0 => x0.value,
      _930: x0 => x0.done,
      _937: x0 => x0.name,
      _938: x0 => x0.x,
      _939: x0 => x0.y,
      _942: x0 => x0.top,
      _943: x0 => x0.right,
      _944: x0 => x0.bottom,
      _945: x0 => x0.left,
      _955: x0 => x0.height,
      _956: x0 => x0.width,
      _957: x0 => x0.scale,
      _958: (x0,x1) => { x0.value = x1 },
      _961: (x0,x1) => { x0.placeholder = x1 },
      _963: (x0,x1) => { x0.name = x1 },
      _964: x0 => x0.selectionDirection,
      _965: x0 => x0.selectionStart,
      _966: x0 => x0.selectionEnd,
      _969: x0 => x0.value,
      _971: (x0,x1,x2) => x0.setSelectionRange(x1,x2),
      _972: x0 => x0.readText(),
      _973: (x0,x1) => x0.writeText(x1),
      _975: x0 => x0.altKey,
      _976: x0 => x0.code,
      _977: x0 => x0.ctrlKey,
      _978: x0 => x0.key,
      _979: x0 => x0.keyCode,
      _980: x0 => x0.location,
      _981: x0 => x0.metaKey,
      _982: x0 => x0.repeat,
      _983: x0 => x0.shiftKey,
      _984: x0 => x0.isComposing,
      _986: x0 => x0.state,
      _987: (x0,x1) => x0.go(x1),
      _989: (x0,x1,x2,x3) => x0.pushState(x1,x2,x3),
      _990: (x0,x1,x2,x3) => x0.replaceState(x1,x2,x3),
      _991: x0 => x0.pathname,
      _992: x0 => x0.search,
      _993: x0 => x0.hash,
      _997: x0 => x0.state,
      _1000: (x0,x1) => x0.createObjectURL(x1),
      _1002: x0 => new Blob(x0),
      _1012: x0 => x0.matches,
      _1016: x0 => x0.matches,
      _1020: x0 => x0.relatedTarget,
      _1022: x0 => x0.clientX,
      _1023: x0 => x0.clientY,
      _1024: x0 => x0.offsetX,
      _1025: x0 => x0.offsetY,
      _1028: x0 => x0.button,
      _1029: x0 => x0.buttons,
      _1030: x0 => x0.ctrlKey,
      _1034: x0 => x0.pointerId,
      _1035: x0 => x0.pointerType,
      _1036: x0 => x0.pressure,
      _1037: x0 => x0.tiltX,
      _1038: x0 => x0.tiltY,
      _1039: x0 => x0.getCoalescedEvents(),
      _1042: x0 => x0.deltaX,
      _1043: x0 => x0.deltaY,
      _1044: x0 => x0.wheelDeltaX,
      _1045: x0 => x0.wheelDeltaY,
      _1046: x0 => x0.deltaMode,
      _1053: x0 => x0.changedTouches,
      _1056: x0 => x0.clientX,
      _1057: x0 => x0.clientY,
      _1060: x0 => x0.data,
      _1063: (x0,x1) => { x0.disabled = x1 },
      _1065: (x0,x1) => { x0.type = x1 },
      _1066: (x0,x1) => { x0.max = x1 },
      _1067: (x0,x1) => { x0.min = x1 },
      _1068: x0 => x0.value,
      _1069: (x0,x1) => { x0.value = x1 },
      _1070: x0 => x0.disabled,
      _1071: (x0,x1) => { x0.disabled = x1 },
      _1073: (x0,x1) => { x0.placeholder = x1 },
      _1075: (x0,x1) => { x0.name = x1 },
      _1076: (x0,x1) => { x0.autocomplete = x1 },
      _1078: x0 => x0.selectionDirection,
      _1079: x0 => x0.selectionStart,
      _1081: x0 => x0.selectionEnd,
      _1084: (x0,x1,x2) => x0.setSelectionRange(x1,x2),
      _1085: (x0,x1) => x0.add(x1),
      _1087: (x0,x1) => { x0.noValidate = x1 },
      _1088: (x0,x1) => { x0.method = x1 },
      _1089: (x0,x1) => { x0.action = x1 },
      _1095: (x0,x1) => x0.getContext(x1),
      _1097: x0 => x0.convertToBlob(),
      _1114: x0 => x0.orientation,
      _1115: x0 => x0.width,
      _1116: x0 => x0.height,
      _1117: (x0,x1) => x0.lock(x1),
      _1136: x0 => new ResizeObserver(x0),
      _1139: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1139(f,arguments.length,x0,x1) }),
      _1147: x0 => x0.length,
      _1148: x0 => x0.iterator,
      _1149: x0 => x0.Segmenter,
      _1150: x0 => x0.v8BreakIterator,
      _1151: (x0,x1) => new Intl.Segmenter(x0,x1),
      _1154: x0 => x0.language,
      _1155: x0 => x0.script,
      _1156: x0 => x0.region,
      _1174: x0 => x0.done,
      _1175: x0 => x0.value,
      _1176: x0 => x0.index,
      _1180: (x0,x1) => new Intl.v8BreakIterator(x0,x1),
      _1181: (x0,x1) => x0.adoptText(x1),
      _1182: x0 => x0.first(),
      _1183: x0 => x0.next(),
      _1184: x0 => x0.current(),
      _1186: () => globalThis.window.FinalizationRegistry,
      _1197: x0 => x0.hostElement,
      _1198: x0 => x0.viewConstraints,
      _1201: x0 => x0.maxHeight,
      _1202: x0 => x0.maxWidth,
      _1203: x0 => x0.minHeight,
      _1204: x0 => x0.minWidth,
      _1205: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1205(f,arguments.length,x0) }),
      _1206: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1206(f,arguments.length,x0) }),
      _1207: (x0,x1) => ({addView: x0,removeView: x1}),
      _1210: x0 => x0.loader,
      _1211: () => globalThis._flutter,
      _1212: (x0,x1) => x0.didCreateEngineInitializer(x1),
      _1213: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1213(f,arguments.length,x0) }),
      _1214: (module,f) => finalizeWrapper(f, function() { return module.exports._1214(f,arguments.length) }),
      _1215: (x0,x1) => ({initializeEngine: x0,autoStart: x1}),
      _1218: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1218(f,arguments.length,x0) }),
      _1219: x0 => ({runApp: x0}),
      _1221: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1221(f,arguments.length,x0,x1) }),
      _1222: x0 => new Promise(x0),
      _1223: x0 => x0.length,
      _1224: () => globalThis.window.ImageDecoder,
      _1225: x0 => x0.tracks,
      _1227: x0 => x0.completed,
      _1229: x0 => x0.image,
      _1235: x0 => x0.displayWidth,
      _1236: x0 => x0.displayHeight,
      _1237: x0 => x0.duration,
      _1240: x0 => x0.ready,
      _1241: x0 => x0.selectedTrack,
      _1242: x0 => x0.repetitionCount,
      _1243: x0 => x0.frameCount,
      _1287: (x0,x1) => x0.createElement(x1),
      _1288: (x0,x1) => x0.querySelector(x1),
      _1289: (x0,x1) => x0.appendChild(x1),
      _1290: x0 => ({type: x0}),
      _1291: (x0,x1) => new Blob(x0,x1),
      _1292: x0 => globalThis.URL.createObjectURL(x0),
      _1294: (x0,x1,x2,x3) => x0.sendCommand(x1,x2,x3),
      _1295: () => globalThis.PdfiumWasmCommunicator,
      _1297: x0 => { globalThis.pdfiumWasmWorkerUrl = x0 },
      _1298: (x0,x1) => x0.writeText(x1),
      _1299: x0 => x0.preventDefault(),
      _1300: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1300(f,arguments.length,x0) }),
      _1301: (x0,x1,x2) => x0.addEventListener(x1,x2),
      _1302: x0 => x0.requestFullscreen(),
      _1303: x0 => x0.exitFullscreen(),
      _1304: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1304(f,arguments.length,x0) }),
      _1305: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1305(f,arguments.length,x0) }),
      _1306: (x0,x1,x2) => x0.setAttribute(x1,x2),
      _1307: (x0,x1,x2,x3) => x0.canUseHlsJs(x1,x2,x3),
      _1308: (x0,x1,x2,x3) => x0.attach(x1,x2,x3),
      _1309: x0 => x0.load(),
      _1310: x0 => x0.play(),
      _1311: (x0,x1,x2) => x0.removeEventListener(x1,x2),
      _1312: x0 => x0.pause(),
      _1313: (x0,x1) => x0.removeAttribute(x1),
      _1314: (x0,x1) => x0.destroy(x1),
      _1315: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1315(f,arguments.length,x0) }),
      _1316: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1316(f,arguments.length,x0) }),
      _1317: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1317(f,arguments.length,x0) }),
      _1318: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1318(f,arguments.length,x0) }),
      _1319: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1319(f,arguments.length,x0) }),
      _1320: x0 => x0.mute(),
      _1321: x0 => x0.unMute(),
      _1322: x0 => x0.disconnect(),
      _1323: x0 => x0.pauseVideo(),
      _1324: x0 => x0.destroy(),
      _1325: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1325(f,arguments.length,x0,x1) }),
      _1326: x0 => new ResizeObserver(x0),
      _1327: (x0,x1) => x0.observe(x1),
      _1328: (x0,x1) => new YT.Player(x0,x1),
      _1329: x0 => x0.getIframe(),
      _1330: x0 => x0.playVideo(),
      _1331: (x0,x1) => x0.loadModule(x1),
      _1332: (x0,x1) => x0.unloadModule(x1),
      _1333: (x0,x1) => x0.add(x1),
      _1334: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1334(f,arguments.length,x0) }),
      _1335: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1335(f,arguments.length,x0) }),
      _1336: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1336(f,arguments.length,x0) }),
      _1337: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1337(f,arguments.length,x0) }),
      _1338: (x0,x1) => x0.end(x1),
      _1339: (x0,x1,x2,x3) => x0.canUseHlsJs(x1,x2,x3),
      _1340: (module,f) => finalizeWrapper(f, function(x0,x1,x2) { return module.exports._1340(f,arguments.length,x0,x1,x2) }),
      _1341: (x0,x1,x2,x3,x4,x5,x6) => x0.attach(x1,x2,x3,x4,x5,x6),
      _1342: (x0,x1) => x0.hasAttribute(x1),
      _1343: (x0,x1) => x0.destroy(x1),
      _1344: x0 => x0.remove(),
      _1345: x0 => x0.createRange(),
      _1346: (x0,x1) => x0.selectNode(x1),
      _1347: x0 => x0.getSelection(),
      _1348: x0 => x0.removeAllRanges(),
      _1349: (x0,x1) => x0.addRange(x1),
      _1350: (x0,x1) => x0.createElement(x1),
      _1351: (x0,x1) => x0.append(x1),
      _1352: (x0,x1,x2) => x0.insertRule(x1,x2),
      _1353: (x0,x1) => x0.add(x1),
      _1354: x0 => x0.preventDefault(),
      _1355: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1355(f,arguments.length,x0) }),
      _1356: (x0,x1,x2) => x0.addEventListener(x1,x2),
      _1357: (module,f) => finalizeWrapper(f, function(x0,x1,x2) { return module.exports._1357(f,arguments.length,x0,x1,x2) }),
      _1358: (x0,x1) => x0.append(x1),
      _1361: (x0,x1) => x0.getResponseHeader(x1),
      _1384: (x0,x1) => x0.item(x1),
      _1387: (x0,x1) => { x0.csp = x1 },
      _1388: x0 => x0.csp,
      _1389: (x0,x1) => x0.getCookieExpirationDate(x1),
      _1392: (x0,x1) => x0.get(x1),
      _1393: x0 => x0.text(),
      _1395: (x0,x1,x2,x3) => x0.addEventListener(x1,x2,x3),
      _1396: (x0,x1,x2,x3) => x0.removeEventListener(x1,x2,x3),
      _1401: (x0,x1,x2,x3) => x0.open(x1,x2,x3),
      _1402: x0 => ({passive: x0}),
      _1403: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1403(f,arguments.length,x0) }),
      _1404: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1404(f,arguments.length,x0) }),
      _1405: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1405(f,arguments.length,x0) }),
      _1406: (x0,x1) => x0.item(x1),
      _1407: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1407(f,arguments.length,x0) }),
      _1408: (x0,x1) => x0.requestAnimationFrame(x1),
      _1409: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1409(f,arguments.length,x0) }),
      _1411: () => new webkitSpeechRecognition(),
      _1412: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1412(f,arguments.length,x0) }),
      _1413: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1413(f,arguments.length,x0) }),
      _1414: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1414(f,arguments.length,x0) }),
      _1415: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1415(f,arguments.length,x0) }),
      _1416: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1416(f,arguments.length,x0) }),
      _1417: x0 => x0.stop(),
      _1418: x0 => x0.abort(),
      _1419: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1419(f,arguments.length,x0) }),
      _1420: x0 => x0.start(),
      _1421: (x0,x1) => x0.item(x1),
      _1422: (x0,x1) => x0.item(x1),
      _1439: x0 => x0.decode(),
      _1440: (x0,x1,x2,x3) => x0.open(x1,x2,x3),
      _1441: (x0,x1,x2) => x0.setRequestHeader(x1,x2),
      _1442: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1442(f,arguments.length,x0) }),
      _1443: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1443(f,arguments.length,x0) }),
      _1444: x0 => x0.send(),
      _1445: () => new XMLHttpRequest(),
      _1446: (x0,x1,x2) => x0.open(x1,x2),
      _1447: x0 => x0.click(),
      _1448: x0 => x0.now(),
      _1449: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1449(f,arguments.length,x0) }),
      _1450: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1450(f,arguments.length,x0) }),
      _1451: x0 => globalThis.Wakelock.toggle(x0),
      _1453: x0 => x0.getGamepads(),
      _1454: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1454(f,arguments.length,x0) }),
      _1455: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1455(f,arguments.length,x0) }),
      _1456: (x0,x1) => x0.getItem(x1),
      _1457: (x0,x1) => x0.removeItem(x1),
      _1458: (x0,x1,x2) => x0.setItem(x1,x2),
      _1488: (x0,x1) => x0.item(x1),
      _1489: () => new FileReader(),
      _1490: (x0,x1) => x0.readAsDataURL(x1),
      _1491: (x0,x1) => x0.readAsArrayBuffer(x1),
      _1492: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1492(f,arguments.length,x0) }),
      _1493: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1493(f,arguments.length,x0) }),
      _1494: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1494(f,arguments.length,x0) }),
      _1495: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1495(f,arguments.length,x0) }),
      _1496: (x0,x1) => x0.removeChild(x1),
      _1497: x0 => new Blob(x0),
      _1498: x0 => globalThis.URL.revokeObjectURL(x0),
      _1568: (x0,x1) => x0.key(x1),
      _1578: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1578(f,arguments.length,x0) }),
      _1579: (x0,x1) => x0.getEntriesByType(x1),
      _1580: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1580(f,arguments.length,x0,x1) }),
      _1581: x0 => new PerformanceObserver(x0),
      _1582: (x0,x1) => ({type: x0,buffered: x1}),
      _1583: (x0,x1) => x0.observe(x1),
      _1584: x0 => x0.getEntries(),
      _1585: (x0,x1) => x0.setResourceTimingBufferSize(x1),
      _1586: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1586(f,arguments.length,x0) }),
      _1587: x0 => x0.clearResourceTimings(),
      _1588: x0 => x0.call(),
      _1589: x0 => x0.estimate(),
      _1590: x0 => x0.persisted(),
      _1591: Date.now,
      _1593: s => new Date(s * 1000).getTimezoneOffset() * 60,
      _1594: s => {
        if (!/^\s*[+-]?(?:Infinity|NaN|(?:\.\d+|\d+(?:\.\d*)?)(?:[eE][+-]?\d+)?)\s*$/.test(s)) {
          return NaN;
        }
        return parseFloat(s);
      },
      _1595: () => typeof dartUseDateNowForTicks !== "undefined",
      _1596: () => 1000 * performance.now(),
      _1597: () => Date.now(),
      _1598: () => {
        // On browsers return `globalThis.location.href`
        if (globalThis.location != null) {
          return globalThis.location.href;
        }
        return null;
      },
      _1599: () => {
        return typeof process != "undefined" &&
               Object.prototype.toString.call(process) == "[object process]" &&
               process.platform == "win32"
      },
      _1600: () => new WeakMap(),
      _1601: (map, o) => map.get(o),
      _1602: (map, o, v) => map.set(o, v),
      _1603: x0 => new WeakRef(x0),
      _1604: x0 => x0.deref(),
      _1605: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1605(f,arguments.length,x0) }),
      _1606: x0 => new FinalizationRegistry(x0),
      _1607: (x0,x1,x2,x3) => x0.register(x1,x2,x3),
      _1608: (x0,x1,x2) => x0.register(x1,x2),
      _1609: (x0,x1) => x0.unregister(x1),
      _1611: () => globalThis.WeakRef,
      _1612: () => globalThis.FinalizationRegistry,
      _1614: s => JSON.stringify(s),
      _1615: s => printToConsole(s),
      _1616: o => {
        if (o === null || o === undefined) return 0;
        if (typeof(o) === 'string') return 1;
        return 2;
      },
      _1617: (o, p, r) => o.replaceAll(p, () => r),
      _1618: (o, p, r) => o.replace(p, () => r),
      _1619: Function.prototype.call.bind(String.prototype.toLowerCase),
      _1620: s => s.toUpperCase(),
      _1621: s => s.trim(),
      _1622: s => s.trimLeft(),
      _1623: s => s.trimRight(),
      _1624: (string, times) => string.repeat(times),
      _1625: Function.prototype.call.bind(String.prototype.indexOf),
      _1626: (s, p, i) => s.lastIndexOf(p, i),
      _1627: (string, token) => string.split(token),
      _1628: Object.is,
      _1632: (o, t) => typeof o === t,
      _1633: (o, c) => o instanceof c,
      _1634: o => Object.keys(o),
      _1636: (o) => {
        const typeofValue = typeof o;
        return (typeofValue === 'object') ||
            typeofValue === 'function';
      },
      _1637: (o,s,v) => o[s] = v,
      _1638: (o, a) => o + a,
      _1648: (o, a) => o == a,
      _1650: (o, a) => o === a,
      _1656: (o) => !!o,
      _1667: (x0,x1) => x0.call(x1),
      _1688: x0 => new Array(x0),
      _1690: x0 => x0.length,
      _1692: (x0,x1) => x0[x1],
      _1693: (x0,x1,x2) => { x0[x1] = x2 },
      _1696: (x0,x1,x2) => new DataView(x0,x1,x2),
      _1698: x0 => new Int8Array(x0),
      _1699: (x0,x1,x2) => new Uint8Array(x0,x1,x2),
      _1701: x0 => new Uint8ClampedArray(x0),
      _1703: x0 => new Int16Array(x0),
      _1705: x0 => new Uint16Array(x0),
      _1707: x0 => new Int32Array(x0),
      _1709: x0 => new Uint32Array(x0),
      _1711: x0 => new Float32Array(x0),
      _1713: x0 => new Float64Array(x0),
      _1733: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1733(f,arguments.length,x0,x1) }),
      _1736: () => Symbol("jsBoxedDartObjectProperty"),
      _1737: x0 => x0.random(),
      _1738: (x0,x1) => x0.getRandomValues(x1),
      _1739: () => globalThis.crypto,
      _1740: () => globalThis.Math,
      _1742: () => globalThis.performance,
      _1743: () => globalThis.JSON,
      _1744: x0 => x0.measure,
      _1745: x0 => x0.mark,
      _1746: x0 => x0.clearMeasures,
      _1747: x0 => x0.clearMarks,
      _1748: (x0,x1,x2,x3) => x0.measure(x1,x2,x3),
      _1749: (x0,x1,x2) => x0.mark(x1,x2),
      _1750: x0 => x0.clearMeasures(),
      _1751: x0 => x0.clearMarks(),
      _1752: (x0,x1) => x0.parse(x1),
      _1753: (ms, c) =>
      setTimeout(() => dartInstance.exports.$invokeCallback(c),ms),
      _1754: (handle) => clearTimeout(handle),
      _1755: (ms, c) =>
      setInterval(() => dartInstance.exports.$invokeCallback(c), ms),
      _1756: (handle) => clearInterval(handle),
      _1757: (c) =>
      queueMicrotask(() => dartInstance.exports.$invokeCallback(c)),
      _1758: () => Date.now(),
      _1759: () => new Error().stack,
      _1760: (exn) => {
        let stackString = exn.toString();
        let frames = stackString.split('\n');
        let drop = 4;
        if (frames[0].startsWith('Error')) {
            drop += 1;
        }
        return frames.slice(drop).join('\n');
      },
      _1761: (s, m) => {
        try {
          return new RegExp(s, m);
        } catch (e) {
          return String(e);
        }
      },
      _1762: (x0,x1) => x0.exec(x1),
      _1763: (x0,x1) => x0.test(x1),
      _1764: x0 => x0.pop(),
      _1766: o => o === undefined,
      _1768: o => typeof o === 'function' && o[jsWrappedDartFunctionSymbol] === true,
      _1770: o => {
        const proto = Object.getPrototypeOf(o);
        return proto === Object.prototype || proto === null;
      },
      _1771: o => o instanceof RegExp,
      _1772: (l, r) => l === r,
      _1773: o => o,
      _1774: o => {
        if (o === undefined || o === null) return 0;
        if (typeof o === 'number') return 1;
        return 2;
      },
      _1775: o => o,
      _1776: o => {
        if (o === undefined || o === null) return 0;
        if (typeof o === 'boolean') return 1;
        return 2;
      },
      _1777: o => o,
      _1778: b => !!b,
      _1779: o => o.length,
      _1781: (o, i) => o[i],
      _1782: f => f.dartFunction,
      _1783: () => ({}),
      _1784: () => [],
      _1786: () => globalThis,
      _1787: (constructor, args) => {
        const factoryFunction = constructor.bind.apply(
            constructor, [null, ...args]);
        return new factoryFunction();
      },
      _1788: (o, p) => p in o,
      _1789: (o, p) => o[p],
      _1790: (o, p, v) => o[p] = v,
      _1791: (o, m, a) => o[m].apply(o, a),
      _1793: o => String(o),
      _1794: (p, s, f) => p.then(s, (e) => f(e, e === undefined)),
      _1795: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1795(f,arguments.length,x0) }),
      _1796: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1796(f,arguments.length,x0,x1) }),
      _1797: o => {
        if (o === undefined) return 1;
        var type = typeof o;
        if (type === 'boolean') return 2;
        if (type === 'number') return 3;
        if (type === 'string') return 4;
        if (o instanceof Array) return 5;
        if (ArrayBuffer.isView(o)) {
          if (o instanceof Int8Array) return 6;
          if (o instanceof Uint8Array) return 7;
          if (o instanceof Uint8ClampedArray) return 8;
          if (o instanceof Int16Array) return 9;
          if (o instanceof Uint16Array) return 10;
          if (o instanceof Int32Array) return 11;
          if (o instanceof Uint32Array) return 12;
          if (o instanceof Float32Array) return 13;
          if (o instanceof Float64Array) return 14;
          if (o instanceof DataView) return 15;
        }
        if (o instanceof ArrayBuffer) return 16;
        // Feature check for `SharedArrayBuffer` before doing a type-check.
        if (globalThis.SharedArrayBuffer !== undefined &&
            o instanceof SharedArrayBuffer) {
            return 17;
        }
        if (o instanceof Promise) return 18;
        return 19;
      },
      _1798: o => [o],
      _1799: (o0, o1) => [o0, o1],
      _1800: (o0, o1, o2) => [o0, o1, o2],
      _1801: (o0, o1, o2, o3) => [o0, o1, o2, o3],
      _1802: (exn) => {
        if (exn instanceof Error) {
          return exn.stack;
        } else {
          return null;
        }
      },
      _1803: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmI8ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      _1804: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmI8ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      _1805: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmI16ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      _1806: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmI16ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      _1807: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmI32ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      _1808: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmI32ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      _1809: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmF32ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      _1810: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmF32ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      _1811: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const getValue = dartInstance.exports.$wasmF64ArrayGet;
        for (let i = 0; i < length; i++) {
          jsArray[jsArrayOffset + i] = getValue(wasmArray, wasmArrayOffset + i);
        }
      },
      _1812: (jsArray, jsArrayOffset, wasmArray, wasmArrayOffset, length) => {
        const setValue = dartInstance.exports.$wasmF64ArraySet;
        for (let i = 0; i < length; i++) {
          setValue(wasmArray, wasmArrayOffset + i, jsArray[jsArrayOffset + i]);
        }
      },
      _1813: x0 => new ArrayBuffer(x0),
      _1814: s => {
        if (/[[\]{}()*+?.\\^$|]/.test(s)) {
            s = s.replace(/[[\]{}()*+?.\\^$|]/g, '\\$&');
        }
        return s;
      },
      _1816: x0 => x0.index,
      _1817: x0 => x0.groups,
      _1818: x0 => x0.flags,
      _1819: x0 => x0.multiline,
      _1820: x0 => x0.ignoreCase,
      _1821: x0 => x0.unicode,
      _1822: x0 => x0.dotAll,
      _1823: (x0,x1) => { x0.lastIndex = x1 },
      _1824: (o, p) => p in o,
      _1825: (o, p) => o[p],
      _1826: (o, p, v) => o[p] = v,
      _1827: (o, p) => delete o[p],
      _1828: x0 => x0.exports,
      _1829: (x0,x1) => globalThis.WebAssembly.instantiateStreaming(x0,x1),
      _1830: x0 => x0.instance,
      _1832: x0 => new WebAssembly.Memory(x0),
      _1833: x0 => x0.buffer,
      _1836: x0 => x0.arrayBuffer(),
      _1838: x0 => x0.sqlite3_initialize,
      _1840: (x0,x1,x2,x3,x4) => x0.sqlite3_open_v2(x1,x2,x3,x4),
      _1841: (x0,x1) => x0.sqlite3_close_v2(x1),
      _1842: (x0,x1,x2) => x0.sqlite3_extended_result_codes(x1,x2),
      _1843: (x0,x1) => x0.sqlite3_extended_errcode(x1),
      _1844: (x0,x1) => x0.sqlite3_errmsg(x1),
      _1845: (x0,x1) => x0.sqlite3_errstr(x1),
      _1846: x0 => x0.sqlite3_error_offset,
      _1850: (x0,x1) => x0.sqlite3_last_insert_rowid(x1),
      _1851: (x0,x1) => x0.sqlite3_changes(x1),
      _1852: (x0,x1,x2,x3,x4,x5) => x0.sqlite3_exec(x1,x2,x3,x4,x5),
      _1855: (x0,x1,x2,x3,x4,x5,x6) => x0.sqlite3_prepare_v3(x1,x2,x3,x4,x5,x6),
      _1856: (x0,x1) => x0.sqlite3_finalize(x1),
      _1857: (x0,x1) => x0.sqlite3_step(x1),
      _1858: (x0,x1) => x0.sqlite3_reset(x1),
      _1859: (x0,x1) => x0.sqlite3_stmt_isexplain(x1),
      _1861: (x0,x1) => x0.sqlite3_column_count(x1),
      _1862: (x0,x1) => x0.sqlite3_bind_parameter_count(x1),
      _1864: (x0,x1,x2) => x0.sqlite3_column_name(x1,x2),
      _1865: (x0,x1,x2,x3,x4,x5) => x0.sqlite3_bind_blob64(x1,x2,x3,x4,x5),
      _1866: (x0,x1,x2,x3) => x0.sqlite3_bind_double(x1,x2,x3),
      _1867: (x0,x1,x2,x3) => x0.sqlite3_bind_int64(x1,x2,x3),
      _1868: (x0,x1,x2) => x0.sqlite3_bind_null(x1,x2),
      _1869: (x0,x1,x2,x3,x4,x5) => x0.sqlite3_bind_text(x1,x2,x3,x4,x5),
      _1870: (x0,x1,x2) => x0.sqlite3_column_blob(x1,x2),
      _1871: (x0,x1,x2) => x0.sqlite3_column_double(x1,x2),
      _1872: (x0,x1,x2) => x0.sqlite3_column_int64(x1,x2),
      _1873: (x0,x1,x2) => x0.sqlite3_column_text(x1,x2),
      _1874: (x0,x1,x2) => x0.sqlite3_column_bytes(x1,x2),
      _1875: (x0,x1,x2) => x0.sqlite3_column_type(x1,x2),
      _1876: (x0,x1) => x0.sqlite3_value_blob(x1),
      _1877: (x0,x1) => x0.sqlite3_value_double(x1),
      _1878: (x0,x1) => x0.sqlite3_value_type(x1),
      _1879: (x0,x1) => x0.sqlite3_value_int64(x1),
      _1880: (x0,x1) => x0.sqlite3_value_text(x1),
      _1881: (x0,x1) => x0.sqlite3_value_bytes(x1),
      _1884: (x0,x1) => x0.sqlite3_user_data(x1),
      _1885: (x0,x1,x2,x3,x4) => x0.sqlite3_result_blob64(x1,x2,x3,x4),
      _1886: (x0,x1,x2) => x0.sqlite3_result_double(x1,x2),
      _1887: (x0,x1,x2,x3) => x0.sqlite3_result_error(x1,x2,x3),
      _1888: (x0,x1,x2) => x0.sqlite3_result_int64(x1,x2),
      _1889: (x0,x1) => x0.sqlite3_result_null(x1),
      _1890: (x0,x1,x2,x3,x4) => x0.sqlite3_result_text(x1,x2,x3,x4),
      _1891: x0 => x0.sqlite3_result_subtype,
      _1910: (x0,x1) => x0.dart_sqlite3_malloc(x1),
      _1911: (x0,x1) => x0.dart_sqlite3_free(x1),
      _1912: (x0,x1,x2,x3) => x0.dart_sqlite3_register_vfs(x1,x2,x3),
      _1913: (x0,x1,x2,x3,x4,x5) => x0.dart_sqlite3_create_scalar_function(x1,x2,x3,x4,x5),
      _1916: x0 => x0.dart_sqlite3_updates,
      _1917: x0 => x0.dart_sqlite3_commits,
      _1918: x0 => x0.dart_sqlite3_rollbacks,
      _1922: x0 => ({initial: x0}),
      _1923: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1923(f,arguments.length,x0) }),
      _1924: (module,f) => finalizeWrapper(f, function(x0,x1,x2,x3,x4) { return module.exports._1924(f,arguments.length,x0,x1,x2,x3,x4) }),
      _1925: (module,f) => finalizeWrapper(f, function(x0,x1,x2) { return module.exports._1925(f,arguments.length,x0,x1,x2) }),
      _1926: (module,f) => finalizeWrapper(f, function(x0,x1,x2,x3) { return module.exports._1926(f,arguments.length,x0,x1,x2,x3) }),
      _1927: (module,f) => finalizeWrapper(f, function(x0,x1,x2,x3) { return module.exports._1927(f,arguments.length,x0,x1,x2,x3) }),
      _1928: (module,f) => finalizeWrapper(f, function(x0,x1,x2) { return module.exports._1928(f,arguments.length,x0,x1,x2) }),
      _1929: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1929(f,arguments.length,x0,x1) }),
      _1930: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1930(f,arguments.length,x0,x1) }),
      _1931: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1931(f,arguments.length,x0) }),
      _1932: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1932(f,arguments.length,x0) }),
      _1933: (module,f) => finalizeWrapper(f, function(x0,x1,x2,x3) { return module.exports._1933(f,arguments.length,x0,x1,x2,x3) }),
      _1934: (module,f) => finalizeWrapper(f, function(x0,x1,x2,x3) { return module.exports._1934(f,arguments.length,x0,x1,x2,x3) }),
      _1935: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1935(f,arguments.length,x0,x1) }),
      _1936: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1936(f,arguments.length,x0,x1) }),
      _1937: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1937(f,arguments.length,x0,x1) }),
      _1938: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1938(f,arguments.length,x0,x1) }),
      _1939: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1939(f,arguments.length,x0,x1) }),
      _1940: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1940(f,arguments.length,x0,x1) }),
      _1941: (module,f) => finalizeWrapper(f, function(x0,x1,x2) { return module.exports._1941(f,arguments.length,x0,x1,x2) }),
      _1942: (module,f) => finalizeWrapper(f, function(x0,x1,x2) { return module.exports._1942(f,arguments.length,x0,x1,x2) }),
      _1943: (module,f) => finalizeWrapper(f, function(x0,x1,x2) { return module.exports._1943(f,arguments.length,x0,x1,x2) }),
      _1944: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1944(f,arguments.length,x0) }),
      _1945: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1945(f,arguments.length,x0) }),
      _1946: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1946(f,arguments.length,x0) }),
      _1947: (module,f) => finalizeWrapper(f, function(x0,x1,x2,x3,x4) { return module.exports._1947(f,arguments.length,x0,x1,x2,x3,x4) }),
      _1948: (module,f) => finalizeWrapper(f, function(x0,x1,x2,x3,x4) { return module.exports._1948(f,arguments.length,x0,x1,x2,x3,x4) }),
      _1949: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1949(f,arguments.length,x0) }),
      _1950: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1950(f,arguments.length,x0) }),
      _1951: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1951(f,arguments.length,x0,x1) }),
      _1952: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._1952(f,arguments.length,x0,x1) }),
      _1953: (module,f) => finalizeWrapper(f, function(x0,x1,x2) { return module.exports._1953(f,arguments.length,x0,x1,x2) }),
      _1955: (x0,x1,x2,x3) => x0.call(x1,x2,x3),
      _1960: x0 => new URL(x0),
      _1961: (x0,x1) => new URL(x0,x1),
      _1962: (x0,x1) => globalThis.fetch(x0,x1),
      _1963: (x0,x1,x2) => x0.postMessage(x1,x2),
      _1964: (x0,x1,x2) => x0.postMessage(x1,x2),
      _1966: (x0,x1) => ({i: x0,p: x1}),
      _1967: (x0,x1) => ({c: x0,r: x1}),
      _1968: x0 => x0.i,
      _1969: x0 => x0.p,
      _1970: x0 => x0.c,
      _1971: x0 => x0.r,
      _1972: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._1972(f,arguments.length,x0) }),
      _1973: (x0,x1) => x0.postMessage(x1),
      _1974: x0 => x0.close(),
      _1976: x0 => new Worker(x0),
      _1978: x0 => x0.getDirectory(),
      _1979: x0 => ({create: x0}),
      _1980: (x0,x1,x2) => x0.getFileHandle(x1,x2),
      _1981: x0 => x0.createSyncAccessHandle(),
      _1982: x0 => x0.close(),
      _1985: x0 => x0.close(),
      _1988: (x0,x1,x2) => x0.open(x1,x2),
      _1994: x0 => x0.start(),
      _1995: x0 => x0.terminate(),
      _1996: (x0,x1) => new SharedWorker(x0,x1),
      _1997: () => new MessageChannel(),
      _2002: x0 => new SharedArrayBuffer(x0),
      _2003: x0 => ({at: x0}),
      _2004: x0 => x0.getSize(),
      _2005: (x0,x1) => x0.truncate(x1),
      _2006: x0 => x0.flush(),
      _2009: x0 => x0.synchronizationBuffer,
      _2010: x0 => x0.communicationBuffer,
      _2011: (x0,x1,x2,x3) => ({clientVersion: x0,root: x1,synchronizationBuffer: x2,communicationBuffer: x3}),
      _2012: (x0,x1) => globalThis.IDBKeyRange.bound(x0,x1),
      _2013: x0 => ({autoIncrement: x0}),
      _2014: (x0,x1,x2) => x0.createObjectStore(x1,x2),
      _2015: x0 => ({unique: x0}),
      _2016: (x0,x1,x2,x3) => x0.createIndex(x1,x2,x3),
      _2017: (x0,x1) => x0.createObjectStore(x1),
      _2018: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2018(f,arguments.length,x0) }),
      _2019: (x0,x1,x2) => x0.transaction(x1,x2),
      _2020: (x0,x1) => x0.objectStore(x1),
      _2022: (x0,x1) => x0.index(x1),
      _2023: x0 => x0.openKeyCursor(),
      _2024: (x0,x1) => x0.getKey(x1),
      _2025: (x0,x1) => ({name: x0,length: x1}),
      _2026: (x0,x1) => x0.put(x1),
      _2027: (x0,x1) => x0.get(x1),
      _2028: (x0,x1) => x0.openCursor(x1),
      _2029: x0 => globalThis.IDBKeyRange.only(x0),
      _2030: (x0,x1,x2) => x0.put(x1,x2),
      _2031: (x0,x1) => x0.update(x1),
      _2032: (x0,x1) => x0.delete(x1),
      _2033: x0 => x0.name,
      _2034: x0 => x0.length,
      _2037: x0 => x0.continue(),
      _2038: () => globalThis.indexedDB,
      _2039: () => globalThis.navigator,
      _2040: (x0,x1) => x0.read(x1),
      _2041: (x0,x1,x2) => x0.read(x1,x2),
      _2042: (x0,x1) => x0.write(x1),
      _2043: (x0,x1,x2) => x0.write(x1,x2),
      _2044: x0 => ({create: x0}),
      _2045: (x0,x1,x2) => x0.getDirectoryHandle(x1,x2),
      _2047: (x0,x1,x2) => globalThis.Atomics.wait(x0,x1,x2),
      _2049: (x0,x1,x2) => globalThis.Atomics.notify(x0,x1,x2),
      _2050: (x0,x1,x2) => globalThis.Atomics.store(x0,x1,x2),
      _2051: (x0,x1) => globalThis.Atomics.load(x0,x1),
      _2052: () => globalThis.Int32Array,
      _2054: () => globalThis.Uint8Array,
      _2056: () => globalThis.DataView,
      _2058: x0 => x0.byteLength,
      _2060: x0 => globalThis.BigInt(x0),
      _2061: x0 => globalThis.Number(x0),
      _2068: x0 => new BroadcastChannel(x0),
      _2069: x0 => globalThis.Array.isArray(x0),
      _2070: (x0,x1) => x0.postMessage(x1),
      _2071: x0 => x0.close(),
      _2072: (x0,x1) => ({kind: x0,table: x1}),
      _2073: x0 => x0.kind,
      _2074: x0 => x0.table,
      _2075: (x0,x1,x2) => ({title: x0,text: x1,url: x2}),
      _2076: (x0,x1) => x0.share(x1),
      _2077: x0 => new JASSUB(x0),
      _2078: (x0,x1,x2) => x0.setCurrentTime(x1,x2),
      _2079: x0 => x0.destroy(),
      _2080: x0 => x0.dispose(),
      _2081: (x0,x1) => { x0.timeOffset = x1 },
      _2082: (x0,x1) => { x0.timeOffset = x1 },
      _2083: () => new XMLHttpRequest(),
      _2084: (x0,x1,x2,x3) => x0.open(x1,x2,x3),
      _2086: (x0,x1,x2) => x0.setRequestHeader(x1,x2),
      _2087: (x0,x1) => x0.send(x1),
      _2088: x0 => x0.send(),
      _2090: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2090(f,arguments.length,x0) }),
      _2091: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2091(f,arguments.length,x0) }),
      _2096: (x0,x1) => new WebSocket(x0,x1),
      _2097: (x0,x1) => x0.send(x1),
      _2098: (x0,x1,x2) => x0.close(x1,x2),
      _2100: x0 => x0.close(),
      _2101: (x0,x1) => x0.item(x1),
      _2103: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2103(f,arguments.length,x0) }),
      _2104: (x0,x1,x2) => x0.sendBeacon(x1,x2),
      _2105: (x0,x1,x2) => x0.open(x1,x2),
      _2106: x0 => x0.abort(),
      _2107: x0 => x0.getAllResponseHeaders(),
      _2108: () => new RTCPeerConnection(),
      _2109: (x0,x1) => x0.createDataChannel(x1),
      _2110: x0 => x0.setLocalDescription(),
      _2111: x0 => x0.close(),
      _2112: () => new AbortController(),
      _2113: x0 => x0.abort(),
      _2114: (x0,x1,x2,x3,x4,x5) => ({method: x0,headers: x1,body: x2,credentials: x3,redirect: x4,signal: x5}),
      _2115: (x0,x1) => globalThis.fetch(x0,x1),
      _2116: (module,f) => finalizeWrapper(f, function(x0,x1,x2) { return module.exports._2116(f,arguments.length,x0,x1,x2) }),
      _2117: (x0,x1) => x0.forEach(x1),
      _2118: x0 => x0.getReader(),
      _2119: x0 => x0.cancel(),
      _2120: x0 => x0.read(),
      _2121: (x0,x1) => x0.querySelectorAll(x1),
      _2122: (x0,x1) => x0.item(x1),
      _2123: (x0,x1) => x0.canPlayType(x1),
      _2124: x0 => globalThis.MediaSource.isTypeSupported(x0),
      _2125: () => new AudioContext(),
      _2126: x0 => x0.close(),
      _2127: (x0,x1) => x0.append(x1),
      _2128: x0 => ({xhrSetup: x0}),
      _2129: x0 => new Hls(x0),
      _2130: () => globalThis.Hls.isSupported(),
      _2132: (x0,x1) => x0.loadSource(x1),
      _2133: (x0,x1) => x0.attachMedia(x1),
      _2136: (module,f) => finalizeWrapper(f, function(x0,x1) { return module.exports._2136(f,arguments.length,x0,x1) }),
      _2146: () => globalThis.window.flutter_inappwebview,
      _2150: (x0,x1) => { x0.nativeCommunication = x1 },
      _2151: (x0,x1) => x0.contains(x1),
      _2152: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2152(f,arguments.length,x0) }),
      _2153: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2153(f,arguments.length,x0) }),
      _2154: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2154(f,arguments.length,x0) }),
      _2155: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2155(f,arguments.length,x0) }),
      _2156: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2156(f,arguments.length,x0) }),
      _2157: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2157(f,arguments.length,x0) }),
      _2158: (module,f) => finalizeWrapper(f, function(x0) { return module.exports._2158(f,arguments.length,x0) }),
      _2159: x0 => x0.getAllKeys(),
      _2162: x0 => x0.webkitSupportsFullscreen,
      _2163: x0 => x0.webkitDisplayingFullscreen,
      _2164: x0 => x0.webkitEnterFullscreen(),
      _2165: x0 => x0.webkitExitFullscreen(),
      _2166: (x0,x1) => x0.querySelectorAll(x1),
      _2167: (x0,x1) => x0.lock(x1),
      _2168: x0 => x0.unlock(),
      _2169: (x0,x1) => x0.fetch(x1),
      _2170: o => o instanceof Array,
      _2171: (a, i) => a.splice(i, 1)[0],
      _2173: (a, l) => a.length = l,
      _2174: a => a.pop(),
      _2175: (a, i) => a.splice(i, 1),
      _2176: (a, s) => a.join(s),
      _2177: (a, s, e) => a.slice(s, e),
      _2179: (a, b) => a == b ? 0 : (a > b ? 1 : -1),
      _2180: a => a.length,
      _2181: (a, l) => a.length = l,
      _2182: (a, i) => a[i],
      _2183: (a, i, v) => a[i] = v,
      _2185: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof ArrayBuffer) return 1;
        if (globalThis.SharedArrayBuffer !== undefined &&
            o instanceof SharedArrayBuffer) {
          return 2;
        }
        return 3;
      },
      _2186: (o, offsetInBytes, lengthInBytes) => {
        var dst = new ArrayBuffer(lengthInBytes);
        new Uint8Array(dst).set(new Uint8Array(o, offsetInBytes, lengthInBytes));
        return new DataView(dst);
      },
      _2187: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof DataView) return 1;
        return 2;
      },
      _2188: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Uint8Array) return 1;
        return 2;
      },
      _2189: (o, start, length) => new Uint8Array(o.buffer, o.byteOffset + start, length),
      _2190: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Int8Array) return 1;
        return 2;
      },
      _2191: (o, start, length) => new Int8Array(o.buffer, o.byteOffset + start, length),
      _2192: o => o instanceof Uint8ClampedArray,
      _2193: (o, start, length) => new Uint8ClampedArray(o.buffer, o.byteOffset + start, length),
      _2194: o => o instanceof Uint16Array,
      _2195: (o, start, length) => new Uint16Array(o.buffer, o.byteOffset + start, length),
      _2196: o => o instanceof Int16Array,
      _2197: (o, start, length) => new Int16Array(o.buffer, o.byteOffset + start, length),
      _2198: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Uint32Array) return 1;
        return 2;
      },
      _2199: (o, start, length) => new Uint32Array(o.buffer, o.byteOffset + start, length),
      _2200: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Int32Array) return 1;
        return 2;
      },
      _2201: (o, start, length) => new Int32Array(o.buffer, o.byteOffset + start, length),
      _2203: (o, start, length) => new BigInt64Array(o.buffer, o.byteOffset + start, length),
      _2204: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Float32Array) return 1;
        return 2;
      },
      _2205: (o, start, length) => new Float32Array(o.buffer, o.byteOffset + start, length),
      _2206: o => {
        if (o === null || o === undefined) return 0;
        if (o instanceof Float64Array) return 1;
        return 2;
      },
      _2207: (o, start, length) => new Float64Array(o.buffer, o.byteOffset + start, length),
      _2208: (a, i) => a.push(i),
      _2209: (t, s) => t.set(s),
      _2210: l => new DataView(new ArrayBuffer(l)),
      _2211: (o) => new DataView(o.buffer, o.byteOffset, o.byteLength),
      _2212: o => o.byteLength,
      _2213: o => o.buffer,
      _2214: o => o.byteOffset,
      _2215: Function.prototype.call.bind(Object.getOwnPropertyDescriptor(DataView.prototype, 'byteLength').get),
      _2216: (b, o) => new DataView(b, o),
      _2217: (b, o, l) => new DataView(b, o, l),
      _2218: Function.prototype.call.bind(DataView.prototype.getUint8),
      _2219: Function.prototype.call.bind(DataView.prototype.setUint8),
      _2220: Function.prototype.call.bind(DataView.prototype.getInt8),
      _2221: Function.prototype.call.bind(DataView.prototype.setInt8),
      _2222: Function.prototype.call.bind(DataView.prototype.getUint16),
      _2223: Function.prototype.call.bind(DataView.prototype.setUint16),
      _2224: Function.prototype.call.bind(DataView.prototype.getInt16),
      _2225: Function.prototype.call.bind(DataView.prototype.setInt16),
      _2226: Function.prototype.call.bind(DataView.prototype.getUint32),
      _2227: Function.prototype.call.bind(DataView.prototype.setUint32),
      _2228: Function.prototype.call.bind(DataView.prototype.getInt32),
      _2229: Function.prototype.call.bind(DataView.prototype.setInt32),
      _2232: Function.prototype.call.bind(DataView.prototype.getBigInt64),
      _2233: Function.prototype.call.bind(DataView.prototype.setBigInt64),
      _2234: Function.prototype.call.bind(DataView.prototype.getFloat32),
      _2235: Function.prototype.call.bind(DataView.prototype.setFloat32),
      _2236: Function.prototype.call.bind(DataView.prototype.getFloat64),
      _2237: Function.prototype.call.bind(DataView.prototype.setFloat64),
      _2238: Function.prototype.call.bind(Number.prototype.toString),
      _2239: Function.prototype.call.bind(BigInt.prototype.toString),
      _2240: Function.prototype.call.bind(Number.prototype.toString),
      _2241: (d, digits) => d.toFixed(digits),
      _2288: x0 => x0.readyState,
      _2290: (x0,x1) => { x0.timeout = x1 },
      _2292: (x0,x1) => { x0.withCredentials = x1 },
      _2293: x0 => x0.upload,
      _2294: x0 => x0.responseURL,
      _2295: x0 => x0.status,
      _2296: x0 => x0.statusText,
      _2298: (x0,x1) => { x0.responseType = x1 },
      _2299: x0 => x0.response,
      _2300: x0 => x0.responseText,
      _2311: x0 => x0.loaded,
      _2312: x0 => x0.total,
      _2358: (x0,x1) => { x0.draggable = x1 },
      _2374: x0 => x0.style,
      _2627: x0 => x0.content,
      _2731: (x0,x1) => { x0.target = x1 },
      _2733: (x0,x1) => { x0.download = x1 },
      _2737: (x0,x1) => { x0.rel = x1 },
      _2758: (x0,x1) => { x0.href = x1 },
      _2850: x0 => x0.src,
      _2851: (x0,x1) => { x0.src = x1 },
      _2854: x0 => x0.name,
      _2855: (x0,x1) => { x0.name = x1 },
      _2856: x0 => x0.sandbox,
      _2857: x0 => x0.allow,
      _2858: (x0,x1) => { x0.allow = x1 },
      _2859: x0 => x0.allowFullscreen,
      _2860: (x0,x1) => { x0.allowFullscreen = x1 },
      _2862: (x0,x1) => { x0.width = x1 },
      _2864: (x0,x1) => { x0.height = x1 },
      _2865: x0 => x0.referrerPolicy,
      _2866: (x0,x1) => { x0.referrerPolicy = x1 },
      _2946: x0 => x0.videoWidth,
      _2947: x0 => x0.videoHeight,
      _2959: (x0,x1) => { x0.kind = x1 },
      _2961: (x0,x1) => { x0.src = x1 },
      _2963: (x0,x1) => { x0.srclang = x1 },
      _2965: (x0,x1) => { x0.label = x1 },
      _2969: x0 => x0.track,
      _2976: x0 => x0.error,
      _2978: (x0,x1) => { x0.src = x1 },
      _2983: (x0,x1) => { x0.crossOrigin = x1 },
      _2986: (x0,x1) => { x0.preload = x1 },
      _2987: x0 => x0.buffered,
      _2988: x0 => x0.readyState,
      _2990: x0 => x0.currentTime,
      _2991: (x0,x1) => { x0.currentTime = x1 },
      _2992: x0 => x0.duration,
      _2993: x0 => x0.paused,
      _2996: x0 => x0.playbackRate,
      _2997: (x0,x1) => { x0.playbackRate = x1 },
      _3002: x0 => x0.ended,
      _3004: (x0,x1) => { x0.autoplay = x1 },
      _3006: (x0,x1) => { x0.loop = x1 },
      _3008: (x0,x1) => { x0.controls = x1 },
      _3009: x0 => x0.volume,
      _3010: (x0,x1) => { x0.volume = x1 },
      _3011: x0 => x0.muted,
      _3012: (x0,x1) => { x0.muted = x1 },
      _3017: x0 => x0.textTracks,
      _3027: x0 => x0.code,
      _3028: x0 => x0.message,
      _3062: (x0,x1) => x0[x1],
      _3064: x0 => x0.length,
      _3073: x0 => x0.kind,
      _3074: x0 => x0.label,
      _3075: x0 => x0.language,
      _3078: x0 => x0.mode,
      _3079: (x0,x1) => { x0.mode = x1 },
      _3080: x0 => x0.cues,
      _3081: x0 => x0.activeCues,
      _3085: (x0,x1) => x0[x1],
      _3087: x0 => x0.length,
      _3091: x0 => x0.startTime,
      _3092: (x0,x1) => { x0.startTime = x1 },
      _3093: x0 => x0.endTime,
      _3094: (x0,x1) => { x0.endTime = x1 },
      _3101: x0 => x0.length,
      _3297: (x0,x1) => { x0.accept = x1 },
      _3311: x0 => x0.files,
      _3337: (x0,x1) => { x0.multiple = x1 },
      _3355: (x0,x1) => { x0.type = x1 },
      _3604: x0 => x0.src,
      _3605: (x0,x1) => { x0.src = x1 },
      _3607: (x0,x1) => { x0.type = x1 },
      _3611: (x0,x1) => { x0.async = x1 },
      _3617: (x0,x1) => { x0.text = x1 },
      _3625: (x0,x1) => { x0.charset = x1 },
      _4074: () => globalThis.window,
      _4112: x0 => x0.document,
      _4115: x0 => x0.location,
      _4134: x0 => x0.navigator,
      _4138: x0 => x0.screen,
      _4140: x0 => x0.innerWidth,
      _4141: x0 => x0.innerHeight,
      _4150: x0 => x0.devicePixelRatio,
      _4390: x0 => x0.crossOriginIsolated,
      _4391: x0 => x0.indexedDB,
      _4393: x0 => x0.performance,
      _4397: x0 => x0.sessionStorage,
      _4398: x0 => x0.localStorage,
      _4406: x0 => x0.href,
      _4408: x0 => x0.origin,
      _4409: x0 => x0.protocol,
      _4419: x0 => x0.search,
      _4499: x0 => x0.clipboard,
      _4501: x0 => x0.geolocation,
      _4504: x0 => x0.mediaDevices,
      _4505: x0 => x0.mediaSession,
      _4506: x0 => x0.permissions,
      _4507: x0 => x0.maxTouchPoints,
      _4520: x0 => x0.userAgent,
      _4526: x0 => x0.onLine,
      _4533: x0 => x0.storage,
      _4571: x0 => x0.data,
      _4572: x0 => x0.origin,
      _4601: x0 => x0.port1,
      _4602: x0 => x0.port2,
      _4604: (x0,x1) => { x0.onmessage = x1 },
      _4682: x0 => x0.port,
      _4717: x0 => x0.length,
      _4901: (x0,x1) => { x0.snapToLines = x1 },
      _4902: x0 => x0.line,
      _4903: (x0,x1) => { x0.line = x1 },
      _4905: (x0,x1) => { x0.lineAlign = x1 },
      _4934: x0 => x0.readyState,
      _4943: x0 => x0.protocol,
      _4947: (x0,x1) => { x0.binaryType = x1 },
      _4950: x0 => x0.code,
      _4951: x0 => x0.reason,
      _5008: x0 => x0.localDescription,
      _5015: x0 => x0.iceGatheringState,
      _5043: x0 => x0.sdp,
      _6102: x0 => x0.destination,
      _6257: x0 => x0.maxChannelCount,
      _6616: x0 => x0.type,
      _6617: x0 => x0.target,
      _6657: x0 => x0.signal,
      _6666: x0 => x0.length,
      _6668: x0 => x0.length,
      _6711: x0 => x0.baseURI,
      _6712: x0 => x0.isConnected,
      _6717: x0 => x0.firstChild,
      _6724: (x0,x1) => { x0.textContent = x1 },
      _6728: () => globalThis.document,
      _6786: x0 => x0.documentElement,
      _6788: x0 => x0.scrollingElement,
      _6807: x0 => x0.body,
      _6809: x0 => x0.head,
      _6821: x0 => x0.visibilityState,
      _6849: x0 => x0.fullscreenElement,
      _6850: x0 => x0.activeElement,
      _7136: x0 => x0.tagName,
      _7137: x0 => x0.id,
      _7138: (x0,x1) => { x0.id = x1 },
      _7141: x0 => x0.classList,
      _7145: x0 => x0.shadowRoot,
      _7147: x0 => x0.scrollTop,
      _7148: (x0,x1) => { x0.scrollTop = x1 },
      _7152: x0 => x0.scrollHeight,
      _7155: x0 => x0.clientWidth,
      _7156: x0 => x0.clientHeight,
      _7162: (x0,x1) => { x0.innerHTML = x1 },
      _7165: x0 => x0.children,
      _7367: x0 => x0.length,
      _7644: x0 => x0.clientX,
      _7645: x0 => x0.clientY,
      _7655: x0 => x0.length,
      _7664: x0 => x0.touches,
      _8481: x0 => x0.value,
      _8483: x0 => x0.done,
      _8644: x0 => x0.size,
      _8645: x0 => x0.type,
      _8652: x0 => x0.name,
      _8658: x0 => x0.length,
      _8663: x0 => x0.result,
      _9158: x0 => x0.url,
      _9160: x0 => x0.status,
      _9161: x0 => x0.ok,
      _9162: x0 => x0.statusText,
      _9163: x0 => x0.headers,
      _9164: x0 => x0.body,
      _9292: (x0,x1) => { x0.lang = x1 },
      _9294: (x0,x1) => { x0.continuous = x1 },
      _9296: (x0,x1) => { x0.interimResults = x1 },
      _9304: (x0,x1) => { x0.onspeechstart = x1 },
      _9312: (x0,x1) => { x0.onresult = x1 },
      _9314: (x0,x1) => { x0.onnomatch = x1 },
      _9316: (x0,x1) => { x0.onerror = x1 },
      _9318: (x0,x1) => { x0.onstart = x1 },
      _9320: (x0,x1) => { x0.onend = x1 },
      _9321: x0 => x0.error,
      _9323: x0 => x0.transcript,
      _9324: x0 => x0.confidence,
      _9325: x0 => x0.length,
      _9327: x0 => x0.length,
      _9329: x0 => x0.results,
      _9455: x0 => x0.orientation,
      _10604: x0 => x0.result,
      _10605: x0 => x0.error,
      _10610: (x0,x1) => { x0.onsuccess = x1 },
      _10612: (x0,x1) => { x0.onerror = x1 },
      _10614: (x0,x1) => { x0.onblocked = x1 },
      _10616: (x0,x1) => { x0.onupgradeneeded = x1 },
      _10618: x0 => x0.oldVersion,
      _10635: x0 => x0.objectStoreNames,
      _10697: x0 => x0.key,
      _10698: x0 => x0.primaryKey,
      _10700: x0 => x0.value,
      _10706: x0 => x0.error,
      _10708: (x0,x1) => { x0.onabort = x1 },
      _10710: (x0,x1) => { x0.oncomplete = x1 },
      _10712: (x0,x1) => { x0.onerror = x1 },
      _10744: x0 => x0.name,
      _10746: x0 => x0.startTime,
      _10747: x0 => x0.duration,
      _10763: x0 => x0.initiatorType,
      _10764: x0 => x0.nextHopProtocol,
      _10774: x0 => x0.requestStart,
      _10775: x0 => x0.responseStart,
      _10776: x0 => x0.responseEnd,
      _10884: x0 => x0.id,
      _10885: x0 => x0.index,
      _10889: x0 => x0.axes,
      _10890: x0 => x0.buttons,
      _10893: x0 => x0.value,
      _10911: x0 => x0.gamepad,
      _11207: (x0,x1) => { x0.backgroundColor = x1 },
      _11253: (x0,x1) => { x0.border = x1 },
      _11531: (x0,x1) => { x0.display = x1 },
      _11695: (x0,x1) => { x0.height = x1 },
      _11751: (x0,x1) => { x0.left = x1 },
      _11889: (x0,x1) => { x0.objectFit = x1 },
      _11923: (x0,x1) => { x0.overflow = x1 },
      _12019: (x0,x1) => { x0.pointerEvents = x1 },
      _12021: (x0,x1) => { x0.position = x1 },
      _12313: (x0,x1) => { x0.top = x1 },
      _12317: (x0,x1) => { x0.transform = x1 },
      _12321: (x0,x1) => { x0.transformOrigin = x1 },
      _12385: (x0,x1) => { x0.width = x1 },
      _12753: x0 => x0.name,
      _12754: x0 => x0.message,
      _13480: () => globalThis.document,
      _13481: () => globalThis.window,
      _13482: () => globalThis.console,
      _13487: (x0,x1) => { x0.height = x1 },
      _13489: (x0,x1) => { x0.width = x1 },
      _13491: (x0,x1) => { x0.pointerEvents = x1 },
      _13494: x0 => x0.head,
      _13495: x0 => x0.classList,
      _13499: (x0,x1) => { x0.innerText = x1 },
      _13500: x0 => x0.style,
      _13502: x0 => x0.sheet,
      _13503: x0 => x0.src,
      _13504: (x0,x1) => { x0.src = x1 },
      _13505: x0 => x0.naturalWidth,
      _13506: x0 => x0.naturalHeight,
      _13513: x0 => x0.offsetX,
      _13514: x0 => x0.offsetY,
      _13515: x0 => x0.button,
      _13521: (x0,x1) => x0.error(x1),
      _13526: x0 => x0.status,
      _13527: (x0,x1) => { x0.responseType = x1 },
      _13529: x0 => x0.response,

    };

    const baseImports = {
      dart2wasm: dart2wasm,
      Math: Math,
      Date: Date,
      Object: Object,
      Array: Array,
      Reflect: Reflect,
      WebAssembly: {
        JSTag: WebAssembly.JSTag,
      },
      "": new Proxy({}, { get(_, prop) { return prop; } }),

    };

    const jsStringPolyfill = {
      "charCodeAt": (s, i) => s.charCodeAt(i),
      "compare": (s1, s2) => {
        if (s1 < s2) return -1;
        if (s1 > s2) return 1;
        return 0;
      },
      "concat": (s1, s2) => s1 + s2,
      "equals": (s1, s2) => s1 === s2,
      "fromCharCode": (i) => String.fromCharCode(i),
      "length": (s) => s.length,
      "substring": (s, a, b) => s.substring(a, b),
      "fromCharCodeArray": (a, start, end) => {
        if (end <= start) return '';

        const read = dartInstance.exports.$wasmI16ArrayGet;
        let result = '';
        let index = start;
        const chunkLength = Math.min(end - index, 500);
        let array = new Array(chunkLength);
        while (index < end) {
          const newChunkLength = Math.min(end - index, 500);
          for (let i = 0; i < newChunkLength; i++) {
            array[i] = read(a, index++);
          }
          if (newChunkLength < chunkLength) {
            array = array.slice(0, newChunkLength);
          }
          result += String.fromCharCode(...array);
        }
        return result;
      },
      "intoCharCodeArray": (s, a, start) => {
        if (s === '') return 0;

        const write = dartInstance.exports.$wasmI16ArraySet;
        for (var i = 0; i < s.length; ++i) {
          write(a, start++, s.charCodeAt(i));
        }
        return s.length;
      },
      "test": (s) => typeof s == "string",
    };


    

    dartInstance = await WebAssembly.instantiate(this.module, {
      ...baseImports,
      ...additionalImports,
      
      "wasm:js-string": jsStringPolyfill,
    });
    dartInstance.exports.$setThisModule(dartInstance);

    return new InstantiatedApp(this, dartInstance);
  }
}

class InstantiatedApp {
  constructor(compiledApp, instantiatedModule) {
    this.compiledApp = compiledApp;
    this.instantiatedModule = instantiatedModule;
  }

  // Call the main function with the given arguments.
  invokeMain(...args) {
    this.instantiatedModule.exports.$invokeMain(args);
  }
}
